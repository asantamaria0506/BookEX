from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('aboutus', views.aboutus, name='aboutus'),
    path('book_detail/<int:book_id>', views.book_detail, name='book_detail'),
    path('book_delete/<int:book_id>', views.book_delete, name='book_delete'),
    path('book_unown/<int:book_id>', views.book_unown, name='book_unown'),
    path('postbook', views.postbook, name='postbook'),
    path('displaybooks', views.displaybooks, name='displaybooks'),
    path('mybooks', views.mybooks, name='mybooks'),
    #created
    path('my_favorites/', views.my_favorites, name='my_favorites'),

    path('view_cart/', views.view_cart, name='view_cart'),
    path('search/', views.search_books, name='search_books'),
    path('edit_comment/<int:comment_id>/', views.edit_comment, name='edit_comment'),
    path('delete_comment/<int:comment_id>/', views.delete_comment, name='delete_comment'),
    path('delete_confirm/<int:comment_id>/', views.delete_confirm, name='delete_confirm'),
    path('remove_from_cart/<int:book_id>/', views.remove_from_cart, name='remove_from_cart'),
    path('add_to_cart/<int:book_id>/', views.add_to_cart, name='add_to_cart'),
    path('checkout_cart', views.checkout_cart, name='checkout_cart'),
    #created
    path('messagebox', views.messagebox, name='messagebox'),
    #created
    path('favorite/<int:book_id>/', views.favorite, name='favorite'),

]
